import pygame as pg
from source.main import main

if __name__=='__main__':
    main()
    pg.quit()